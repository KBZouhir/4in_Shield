package com.example.a4in_shield;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import stic.cdam.a4in_shield.R;

public class ConfirmProfil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_profil);


    }
}