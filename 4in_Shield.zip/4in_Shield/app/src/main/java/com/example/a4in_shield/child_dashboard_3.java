package com.example.a4in_shield;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;

import stic.cdam.a4in_shield.R;

public class child_dashboard_3 extends AppCompatActivity {


    BarChart barChart;
    TextView t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child_dashboard3);
        barChart = findViewById(R.id.bargraph);
        t = findViewById(R.id.text);
        System.out.println(t.getText());


        ArrayList<BarEntry> barEntries = new ArrayList<>();
        barEntries.add(new BarEntry(44f, 0));
        barEntries.add(new BarEntry(22f, 1));
        barEntries.add(new BarEntry(36f, 2));
        barEntries.add(new BarEntry(80f, 3));
        barEntries.add(new BarEntry(54f, 4));
        barEntries.add(new BarEntry(90f, 5));
    }
}